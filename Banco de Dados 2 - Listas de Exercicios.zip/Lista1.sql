1)
select aut.nome, inst.nome
from autor aut join instituicao inst on aut.codigo_instituicao = inst.codigo;

2)
select aut.nome, coalesce(inst.nome, 'Sem Instituição')
from autor aut left join instituicao inst on aut.codigo_instituicao = inst.codigo;

3)
select coalesce(aut.nome, 'Sem Autor'), coalesce(inst.nome, 'Sem Instituição')
from autor aut full join instituicao inst on aut.codigo_instituicao = inst.codigo;

4)
select art.titulo, cat.nome
from artigo art join categoria cat on art.codigo_categoria = cat.codigo
order by art.titulo
limit 3 offset 1;

5)
select aut.nome, art.titulo, cat.nome
from autor aut join artigo_autor artaut on aut.codigo = artaut.codigo_autor join artigo art on art.codigo = artaut.codigo_artigo join categoria cat on cat.codigo = art.codigo_categoria
where aut.renda < 5500;

6)
select aut.nome, art.titulo, cat.nome, inst.nome
from autor aut join artigo_autor artaut on aut.codigo = artaut.codigo_autor join artigo art on art.codigo = artaut.codigo_artigo join categoria cat on cat.codigo = art.codigo_categoria join instituicao inst on aut.codigo_instituicao = inst.codigo
where art.preco_venda between 100 and 250;


CREATE TABLE categoria(
  codigo serial NOT NULL,
  nome varchar(50) NOT NULL,
  primary key (codigo)
);
CREATE TABLE instituicao(
  codigo serial NOT NULL,
  nome varchar(50) NOT NULL,
  data_fundacao date,
  primary key (codigo)
);
CREATE TABLE artigo(
  codigo serial NOT NULL,
  titulo varchar(50) NOT NULL,
  data_publicacao date,
  status varchar(50) NOT NULL,
  url varchar (50) NOT NULL,
  preco_venda numeric(10,2),
  codigo_categoria int,
  primary key (codigo),
  FOREIGN KEY (codigo_categoria) REFERENCES categoria(codigo)
);
CREATE TABLE autor(
  codigo serial NOT NULL,
  nome varchar(50) NOT NULL,
  cpf varchar(11) unique NOT NULL,
  renda numeric(10,2),
  email varchar(50) NOT NULL,
  data_nascimento date,
  data_cadastro timestamp,
  ativo boolean,
  codigo_instituicao int,
  primary key(codigo),
  foreign key(codigo_instituicao) references instituicao(codigo)
);
CREATE TABLE artigo_autor(
  codigo_artigo int,
  codigo_autor int,
  primary key (codigo_artigo, codigo_autor),
  FOREIGN KEY(codigo_artigo) REFERENCES artigo(codigo),
  FOREIGN KEY(codigo_autor) REFERENCES autor(codigo)
);
insert into categoria(nome)
values ('Banco de Dados');
insert into categoria(nome)
values ('Engenharia de Software');
insert into categoria(nome)
values ('Grafos');
insert into instituicao(nome, data_fundacao)
values ('IFMS', '2008-12-29');
insert into instituicao(nome, data_fundacao)
values ('UFMS', '1962-03-01');
insert into instituicao(nome, data_fundacao)
values ('UEMS', '1993-12-22');
insert into instituicao(nome, data_fundacao)
values ('UFGD', '2005-08-01');
insert into artigo(titulo, data_publicacao, status, url, preco_venda, codigo_categoria)
values('Left Join','2020-09-08','finalizado','http://www.artigosbd.publicado/',125.99, 1);
insert into artigo(titulo, data_publicacao, status, url, preco_venda, codigo_categoria)
values('Requisitos','2018-07-17','finalizado','http://www.artigoes.publicado/',89.99, 2);
insert into artigo(titulo, data_publicacao, status, url, preco_venda, codigo_categoria)
values('Algoritmo de Dijkstra','2019-03-04','finalizado','http://www.artigosgrafos.publicado/',69.99, 3);
insert into artigo(titulo, data_publicacao, status, url, preco_venda, codigo_categoria)
values('Gerenciamento   de   Transações',current_date,'Em
revisão','http://www.artigosbd.publicado/',300.90, 1);
insert into artigo(titulo, data_publicacao, status, url, preco_venda, codigo_categoria)
values('Triggers','2017-04-21','finalizado','http://www.artigosbd.publicado/', 119.99, 1);
insert into autor(nome, cpf, renda, email, data_nascimento, data_cadastro, ativo, codigo_instituicao)
values('Fulano   Pereira',   '11199999922',   1200.01,   'fulanopereira@email.com',   '1985-12-21',
current_timestamp, '1', 1);
insert into autor(nome, cpf, renda, email, data_nascimento, data_cadastro, ativo)
values('Siqueira   Beltrano',   '78214698752',   6000.00,   'siqueirabeltrano1@email.com','1989-01-15','2016-05-09', '1');
insert into autor(nome, cpf, renda, email, data_nascimento, data_cadastro, ativo, codigo_instituicao)
values('Cicrano Silva', '55566644433', 2500.00, 'cicranopereira@email.com', '1973-05-11', '2017-05-06 16:00:21', '1',1);
insert into autor(nome, cpf, renda, email, data_nascimento, data_cadastro, ativo, codigo_instituicao)
values('Beltrano   Santos',   '22211188899',   4800.00,   'beltranosantos@email.com',   '1988-07-08',
current_timestamp, '1', 2);
insert into autor(nome, cpf, renda, email, data_nascimento, data_cadastro, ativo, codigo_instituicao)
values('Fulana   Silva',   '33377744419',   7000.00,   'fulanasilva@email.com',   '2000-02-01',   '2020-02-02
08:25:00', '1', 3);
insert into autor(nome, cpf, renda, email, data_nascimento, data_cadastro, ativo, codigo_instituicao)
values('Maria   Joana',   '77377744419',   9000.00,   'mjoana@email.com',   '2001-01-03',   '2018-01-02
09:25:00', '0', 3);
insert into artigo_autor(codigo_artigo, codigo_autor)
values(1,1);
insert into artigo_autor(codigo_artigo, codigo_autor)
values(5,1);
insert into artigo_autor(codigo_artigo, codigo_autor)
values(4,1);
insert into artigo_autor(codigo_artigo, codigo_autor)
values(5,2);
insert into artigo_autor(codigo_artigo, codigo_autor)
values(1,2);
insert into artigo_autor(codigo_artigo, codigo_autor)
values(2,3);
insert into artigo_autor(codigo_artigo, codigo_autor)
values(3,4);
insert into artigo_autor(codigo_artigo, codigo_autor)
values(2,6);
insert into artigo_autor(codigo_artigo, codigo_autor)
values(3,5);

drop table categoria, instituicao, artigo, autor, artigo_autor;
