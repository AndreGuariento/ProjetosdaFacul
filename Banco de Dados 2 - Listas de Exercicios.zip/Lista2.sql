1)
select dep.nome, trunc(avg(func.salario),2) as media
from funcionario func join departamento dep on func.codigo_departamento = dep.codigo
group by dep.nome;

2)
select dep.nome, count(*)
from funcionario func join departamento dep on func.codigo_departamento = dep.codigo
group by dep.nome
having count(*) > 1;

3)
select proj.nome, count(*)
from funcionario func join departamento dep on func.codigo_departamento = dep.codigo join projeto proj on dep.codigo = proj.codigo_departamento
group by proj.nome
order by proj.nome;

4)
select dep.nome, min(proj.verba) as minimo, max(proj.verba) as maximo
from funcionario func join departamento dep on func.codigo_departamento = dep.codigo join projeto proj on dep.codigo = proj.codigo_departamento
group by dep.nome;


5)
select func.nome
from funcionario func join departamento dep on func.codigo_departamento = dep.codigo join localizacao loc on dep.codigo_localizacao = loc.codigo
where func.nome ilike '%o%' 
and func.nome ilike '______%'
and loc.nome = 'Campo Grande';

-----------------------------

CREATE TABLE localizacao (
codigo serial NOT NULL,
nome varchar(50) NOT NULL,
primary key (codigo)
);

CREATE TABLE departamento (
codigo serial NOT NULL,
nome varchar(50) NOT NULL,
data_criacao date,
codigo_localizacao int,
primary key (codigo),
foreign key (codigo_localizacao) references localizacao(codigo)
);

CREATE TABLE funcionario (
codigo serial NOT NULL,
nome varchar(50) NOT NULL,
salario numeric(10,2),
data_contratacao date,
data_cadastro date,
codigo_departamento int,
primary key (codigo),
foreign key (codigo_departamento) references departamento(codigo)
);

CREATE TABLE projeto (
codigo serial NOT NULL,
nome varchar(50) NOT NULL,
verba numeric(10,2),
ativo boolean,
codigo_departamento int,
primary key (codigo),
foreign key (codigo_departamento) references departamento(codigo)
);

CREATE TABLE funcionario_projeto (
codigo_funcionario int,
codigo_projeto int,
primary key (codigo_funcionario, codigo_projeto),
foreign key (codigo_funcionario) references funcionario(codigo),
foreign key (codigo_projeto) references projeto(codigo)
);

insert into localizacao(nome)
values ('Campo Grande');
insert into localizacao(nome)
values ('Dourados');
insert into localizacao(nome)
values ('Três Lagoas');
insert into localizacao(nome)
values ('Corumbá');
insert into localizacao(nome)
values ('Ponta Porã');

insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Tecnologia da Informação',  current_date-3000, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Financeiro',  current_date-4000, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Logística',  current_date-1000, 2);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Importação',  current_date-2000, 5);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Recursos Humanos',  current_date-300, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
 values ('Vestuário',  current_date, 4);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Estoque',  current_date-3500, 3);

insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Tomas', 5000.00, '2000-09-12', '2000-09-12 08:00:00',  1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Jaqueline', 2000.00, '2010-10-25','2010-10-25 12:35:00',  2);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Jorge José', 3000.00, current_date, current_timestamp,  3);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Vagner', 3500.00,  '2000-01-01', '2000-01-02 08:00:00', 4);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Lainez', 9000.00,  '2018-10-12', '2018-10-12 08:00:00', 5);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Anderson', 10000.00, '2020-11-12', '2020-11-12 09:55:00', 1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Odair', 1000.00,  '2019-07-05', '2019-07-05 14:55:00', 6);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Felipe', 15000.00, '2016-04-05', '2016-04-06 17:33:00',  1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Joaquina', 2000.00, '2014-12-04', '2014-12-04 13:13:00',   1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Josefina Amaral', 3000.00, current_date, current_timestamp,  null);

insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Desenvolvimento Scrum', 8999, '1', 1);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Economia Industrial', 7898, '1', 2);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Estudo de Grafos em Rodovias', 98000,'1',  3);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Relações Internacionais', 10000, '0', 4);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Gerência de Recursos',9874, '0', 5);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Tendência em Produtos', 18654, '1', 6);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Armazenamento de Produtos Perecíveis', 75000, '1', 7);

insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (1, 1);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (2 , 2);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (3 , 3);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (4 , 4);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (5 , 5);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (6 , 6);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (7, 7);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (8, 2); 