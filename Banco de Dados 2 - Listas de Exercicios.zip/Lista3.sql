1)
select dep.nome, trunc(avg(func.salario),2) as media_salarial
from funcionario func join departamento dep on func.codigo_departamento = dep.codigo
group by dep.nome;

2)
select dep.nome, trunc(avg(func.salario),0) as media_salarial
from funcionario func join departamento dep on func.codigo_departamento = dep.codigo
group by dep.nome;

3)
select to_char(func.data_contratacao,'DD/MM/YYYY'), func.nome
from funcionario func
group by func.nome, func.data_contratacao
limit 5 offset 3;

4)
select proj.nome, proj.verba
from projeto proj
where proj.verba = (select max(proj2.verba) from projeto proj2)

5)
select func.nome, extract (year from age(func.data_contratacao)) as tempo
from funcionario func join departamento dep on func.codigo_departamento = dep.codigo 
join localizacao loc on dep.codigo_localizacao = loc.codigo
where loc.nome ILIKE 'Campo Grande';

6)
select to_char(current_date - 100, 'DD/MM/YYYY') as data_cadastro;

\\select to_char(func.data_contratacao,'DD/MM/YYYY')
\\from funcionario func
\\where age(func.data_contratacao) > '0 years 3 mons 10 days'

7)
select distinct func.nome, to_char(func.data_cadastro,'DD/MM/YYYY HH24:MI:SS'), proj.nome
from funcionario func join funcionario_projeto funcproj on funcproj.codigo_funcionario = func.codigo
join projeto proj on funcproj.codigo_projeto = proj.codigo
where func.nome LIKE '_____' and func.nome LIKE '%o' and proj.ativo = '1';

8)
select exists(select proj.nome from projeto proj where proj.nome like 'TI MOBILE')

CREATE TABLE localizacao
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
primary key (codigo)
);


CREATE TABLE departamento
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
codigo_localizacao int,
data_criacao date,
primary key (codigo),
FOREIGN KEY(codigo_localizacao) REFERENCES localizacao(codigo)
);



CREATE TABLE funcionario
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
salario numeric(10,2),
data_contratacao date,
data_cadastro timestamp,
codigo_departamento int,
primary key (codigo),
FOREIGN KEY(codigo_departamento) REFERENCES departamento(codigo)
);


CREATE TABLE projeto
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
verba numeric(12,2),
ativo boolean,
codigo_departamento int,
primary key (codigo),
FOREIGN KEY(codigo_departamento) REFERENCES departamento(codigo)
);

CREATE TABLE funcionario_projeto
( codigo_funcionario int  NOT NULL,
  codigo_projeto int  NOT NULL,
primary key (codigo_funcionario, codigo_projeto),
FOREIGN KEY(codigo_funcionario) REFERENCES funcionario(codigo),
FOREIGN KEY(codigo_projeto) REFERENCES projeto(codigo)
);


insert into localizacao(nome)
values ('Campo Grande');
insert into localizacao(nome)
values ('Dourados');
insert into localizacao(nome)
values ('Três Lagoas');
insert into localizacao(nome)
values ('Corumbá');
insert into localizacao(nome)
values ('Ponta Porã');

insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Tecnologia da Informação',  current_date-3000, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Financeiro',  current_date-4000, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Logística',  current_date-1000, 2);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Importação',  current_date-2000, 5);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Recursos Humanos',  current_date-300, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
 values ('Vestuário',  current_date, 4);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Estoque',  current_date-3500, 3);

insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Tomas', 5000.00, '2000-09-12', '2000-09-12 08:00:00',  1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Jaqueline', 2000.00, '2010-10-25','2010-10-25 12:35:00',  2);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Jorge José', 3000.00, current_date, current_timestamp,  3);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Vagner', 3500.00,  '2000-01-01', '2000-01-02 08:00:00', 4);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Lainez', 9000.00,  '2018-10-12', '2018-10-12 08:00:00', 5);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Anderson', 10000.00, '2020-11-12', '2020-11-12 09:55:00', 1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Odair', 1000.00,  '2019-07-05', '2019-07-05 14:55:00', 6);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Felipe', 15000.00, '2016-04-05', '2016-04-06 17:33:00',  1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Joaquina', 2000.00, '2014-12-04', '2014-12-04 13:13:00',   1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Josefina Amaral', 3000.00, current_date, current_timestamp,  null);

insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Desenvolvimento Scrum', 8999, '1', 1);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Economia Industrial', 7898, '1', 2);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Estudo de Grafos em Rodovias', 98000,'1',  3);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Relações Internacionais', 10000, '0', 4);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Gerência de Recursos',9874, '0', 5);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Tendência em Produtos', 18654, '1', 6);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Armazenamento de Produtos Perecíveis', 75000, '1', 7);

insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (1, 1);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (2 , 2);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (3 , 3);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (4 , 4);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (5 , 5);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (6 , 6);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (7, 7);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (8, 2);