1)
create or replace function sub (n1 integer, n2 integer)
returns integer as $$
DECLARE
	res integer;
BEGIN
	res = n1 - n2;
	
	return res;
end;
$$ language plpgsql;

select sub(20, 10);

2)
create or replace function idade (ano integer)
returns integer as $$
DECLARE
	idade integer;
BEGIN
	idade = extract(year from current_date) - ano;
	
	return idade;
end;
$$ language plpgsql;

select idade(1998);

3)
create or replace function maiorsal ()
returns integer as $$
DECLARE
	maior integer;
BEGIN
	select max(func.salario) into maior
	from funcionario func;
	
	return maior;
end;
$$ language plpgsql;

select maiorsal();

4)
create or replace function funcnum (nomdep varchar)
returns integer as $$
DECLARE
	qnt integer;
BEGIN
	select count(*) into qnt
	from funcionario func join departamento dep on func.codigo_departamento = dep.codigo
	where dep.nome ilike nomdep;
	
	return qnt;
end;
$$ language plpgsql;

select funcnum('importação');

5)

create or replace function nvDep(nom varchar, data date, loc varchar)
returns void as $$
DECLARE
	cod integer;
BEGIN
	select loc.codigo into cod_loc
	from localizacao loc
	where loc.nome ilike nome_loc;
	
	insert into departamento(nome, data_criacao, codigo_localizacao)
	values(nom, data, cod_loc);
END
$$ language plpgsql;


/*create or replace function nvDep (nom varchar, data date, loc varchar)
returns void as $$
DECLARE
	cod integer;
BEGIN
	if loc ilike 'Campo Grande' then
	insert into departamento(nome,data_criacao,codigo_localizacao)
	values (nom,  data, 1);
	elsif loc ilike 'Dourados' then
	insert into departamento(nome,data_criacao,codigo_localizacao)
	values (nom,  data, 2);
	elsif loc ilike 'Três Lagoas' then
	insert into departamento(nome,data_criacao,codigo_localizacao)
	values (nom,  data, 3);
	elsif loc ilike 'Corumbá' then
	insert into departamento(nome,data_criacao,codigo_localizacao)
	values (nom,  data, 4);
	elsif loc ilike 'Ponta Porã' then
	insert into departamento(nome,data_criacao,codigo_localizacao)
	values (nom,  data, 5);
	else 
	end if;
	end;
$$ language plpgsql;*/

select nvDep('Novo', current_date, 'Ponta Porã');

CREATE TABLE localizacao
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
primary key (codigo)
);


CREATE TABLE departamento
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
codigo_localizacao int,
data_criacao date,
primary key (codigo),
FOREIGN KEY(codigo_localizacao) REFERENCES localizacao(codigo)
);



CREATE TABLE funcionario
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
salario numeric(10,2),
data_contratacao date,
data_cadastro timestamp,
codigo_departamento int,
primary key (codigo),
FOREIGN KEY(codigo_departamento) REFERENCES departamento(codigo)
);


CREATE TABLE projeto
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
verba numeric(12,2),
ativo boolean,
codigo_departamento int,
primary key (codigo),
FOREIGN KEY(codigo_departamento) REFERENCES departamento(codigo)
);

CREATE TABLE funcionario_projeto
( codigo_funcionario int  NOT NULL,
  codigo_projeto int  NOT NULL,
primary key (codigo_funcionario, codigo_projeto),
FOREIGN KEY(codigo_funcionario) REFERENCES funcionario(codigo),
FOREIGN KEY(codigo_projeto) REFERENCES projeto(codigo)
);


insert into localizacao(nome)
values ('Campo Grande');
insert into localizacao(nome)
values ('Dourados');
insert into localizacao(nome)
values ('Três Lagoas');
insert into localizacao(nome)
values ('Corumbá');
insert into localizacao(nome)
values ('Ponta Porã');

insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Tecnologia da Informação',  current_date-3000, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Financeiro',  current_date-4000, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Logística',  current_date-1000, 2);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Importação',  current_date-2000, 5);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Recursos Humanos',  current_date-300, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
 values ('Vestuário',  current_date, 4);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Estoque',  current_date-3500, 3);

insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Tomas', 5000.00, '2000-09-12', '2000-09-12 08:00:00',  1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Jaqueline', 2000.00, '2010-10-25','2010-10-25 12:35:00',  2);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Jorge José', 3000.00, current_date, current_timestamp,  3);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Vagner', 3500.00,  '2000-01-01', '2000-01-02 08:00:00', 4);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Lainez', 9000.00,  '2018-10-12', '2018-10-12 08:00:00', 5);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Anderson', 10000.00, '2020-11-12', '2020-11-12 09:55:00', 1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Odair', 1000.00,  '2019-07-05', '2019-07-05 14:55:00', 6);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Felipe', 15000.00, '2016-04-05', '2016-04-06 17:33:00',  1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Joaquina', 2000.00, '2014-12-04', '2014-12-04 13:13:00',   1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Josefina Amaral', 3000.00, current_date, current_timestamp,  null);

insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Desenvolvimento Scrum', 8999, '1', 1);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Economia Industrial', 7898, '1', 2);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Estudo de Grafos em Rodovias', 98000,'1',  3);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Relações Internacionais', 10000, '0', 4);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Gerência de Recursos',9874, '0', 5);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Tendência em Produtos', 18654, '1', 6);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Armazenamento de Produtos Perecíveis', 75000, '1', 7);

insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (1, 1);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (2 , 2);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (3 , 3);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (4 , 4);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (5 , 5);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (6 , 6);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (7, 7);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (8, 2);