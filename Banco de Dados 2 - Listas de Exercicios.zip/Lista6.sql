1)
create or replace function funcionario()
returns SETOF funcionario as $$
DECLARE
	saida funcionario%ROWTYPE;
BEGIN
	for saida in select * from funcionario func loop
	
	return next saida;
	
	end loop;
end;
$$ language plpgsql;

select * from funcionario()

2)
create or replace function funcionarioano (ano integer)
returns SETOF funcionario as $$
DECLARE
	saida funcionario%ROWTYPE;
BEGIN	
	for saida in select * from funcionario func where extract(year from func.data_cadastro) = ano loop
	return next saida;
	
	end loop;
end;
$$ language plpgsql;

select * from funcionarioano(2010)

3)
create or replace function aumsal (aum numeric, depar varchar)
returns void as $$
DECLARE
	cod integer;
BEGIN
	select func.codigo into cod
	from funcionario func join departamento dep on func.codigo_departamento = dep.codigo
	where dep.nome ilike depar;
	
	update funcionario
	set salario = salario * aum
	where codigo = cod;

	end;
$$ language plpgsql;

select aumsal(1.1, 'Recursos Humanos')

4)
create type saida2 as (nome varchar, tempcad integer, depnome varchar, projnome varchar);

create or replace function nomtemdeppro ()
returns SETOF saida2 as $$
DECLARE
	s saida2;
BEGIN	
	for s in select func.nome, extract(year from func.data_cadastro), dep.nome, proj.nome
	from funcionario func join departamento dep on func.codigo_departamento = dep.codigo
	join projeto proj on proj.codigo_departamento = dep.codigo loop
	
	return next s;
	
	end loop;
END
$$ language plpgsql;

select * from nomtemdeppro();

5)
create type saida as (nome varchar, depnome varchar, verba numeric, locais varchar);

create or replace function nomdepverloc ()
returns SETOF saida as $$
DECLARE
	s saida;
BEGIN	
	for s in select proj.nome, dep.nome, proj.verba, loc.nome
	from departamento dep join projeto proj on proj.codigo_departamento = dep.codigo
	join localizacao loc on dep.codigo_localizacao = loc.codigo loop
	
	return next s;
	
	end loop;
END
$$ language plpgsql;

select * from nomdepverloc();

6)
create or replace function novoproj(nom varchar, ver numeric, ati boolean, coddep integer)
returns integer as $$
BEGIN	
	if exists(select proj.nome, proj.verba, proj.ativo, dep.codigo 
					from projeto proj join departamento dep on proj.codigo_departamento = dep.codigo
					where proj.nome ilike nom and proj.verba = ver and proj.ativo = ati 
					and dep.codigo = coddep) = 'false' then
					insert into projeto(nome, verba, ativo, codigo_departamento)
					values (nom, ver, ati, coddep);
					return '1';
					else
					return '-1';
					end if;
END
$$ language plpgsql;

select novoproj('Relações Nacionais', 5423.50, '1', 4);

----------------------------------------

CREATE TABLE localizacao
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
primary key (codigo)
);


CREATE TABLE departamento
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
codigo_localizacao int,
data_criacao date,
primary key (codigo),
FOREIGN KEY(codigo_localizacao) REFERENCES localizacao(codigo)
);



CREATE TABLE funcionario
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
salario numeric(10,2),
data_contratacao date,
data_cadastro timestamp,
codigo_departamento int,
primary key (codigo),
FOREIGN KEY(codigo_departamento) REFERENCES departamento(codigo)
);


CREATE TABLE projeto
( codigo serial  NOT NULL,
nome varchar(50) NOT NULL,
verba numeric(12,2),
ativo boolean,
codigo_departamento int,
primary key (codigo),
FOREIGN KEY(codigo_departamento) REFERENCES departamento(codigo)
);

CREATE TABLE funcionario_projeto
( codigo_funcionario int  NOT NULL,
  codigo_projeto int  NOT NULL,
primary key (codigo_funcionario, codigo_projeto),
FOREIGN KEY(codigo_funcionario) REFERENCES funcionario(codigo),
FOREIGN KEY(codigo_projeto) REFERENCES projeto(codigo)
);


insert into localizacao(nome)
values ('Campo Grande');
insert into localizacao(nome)
values ('Dourados');
insert into localizacao(nome)
values ('Três Lagoas');
insert into localizacao(nome)
values ('Corumbá');
insert into localizacao(nome)
values ('Ponta Porã');

insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Tecnologia da Informação',  current_date-3000, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Financeiro',  current_date-4000, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Logística',  current_date-1000, 2);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Importação',  current_date-2000, 5);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Recursos Humanos',  current_date-300, 1);
insert into departamento(nome,data_criacao,codigo_localizacao)
 values ('Vestuário',  current_date, 4);
insert into departamento(nome,data_criacao,codigo_localizacao)
values ('Estoque',  current_date-3500, 3);

insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Tomas', 5000.00, '2000-09-12', '2000-09-12 08:00:00',  1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Jaqueline', 2000.00, '2010-10-25','2010-10-25 12:35:00',  2);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Jorge José', 3000.00, current_date, current_timestamp,  3);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Vagner', 3500.00,  '2000-01-01', '2000-01-02 08:00:00', 4);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Lainez', 9000.00,  '2018-10-12', '2018-10-12 08:00:00', 5);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Anderson', 10000.00, '2020-11-12', '2020-11-12 09:55:00', 1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Odair', 1000.00,  '2019-07-05', '2019-07-05 14:55:00', 6);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Felipe', 15000.00, '2016-04-05', '2016-04-06 17:33:00',  1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Joaquina', 2000.00, '2014-12-04', '2014-12-04 13:13:00',   1);
insert into funcionario(nome, salario, data_contratacao, data_cadastro, codigo_departamento)
values ('Josefina Amaral', 3000.00, current_date, current_timestamp,  null);

insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Desenvolvimento Scrum', 8999, '1', 1);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Economia Industrial', 7898, '1', 2);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Estudo de Grafos em Rodovias', 98000,'1',  3);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Relações Internacionais', 10000, '0', 4);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Gerência de Recursos',9874, '0', 5);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Tendência em Produtos', 18654, '1', 6);
insert into projeto(nome, verba,  ativo, codigo_departamento)
values ('Armazenamento de Produtos Perecíveis', 75000, '1', 7);

insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (1, 1);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (2 , 2);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (3 , 3);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (4 , 4);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (5 , 5);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (6 , 6);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (7, 7);
insert into funcionario_projeto(codigo_funcionario, codigo_projeto)
values (8, 2);