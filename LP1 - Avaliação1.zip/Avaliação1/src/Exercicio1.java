/*
1) Faça um programa que calcule a média final de oito alunos em uma disciplina, informe o conceito referente a média final e tudo que for solicitado. Para calcular a média final é necessário calcular a média simples das notas de dois bimestres. Cada bimestre é formado por duas notas (Prova e Lista) e a média bimestral é calculada considerando que a prova possui peso 8 e a lista peso 2. Todas as notas devem serinformadas pelo usuário e o programa deve ter como saída:  [3,5 pontos]
•A média de cada bimestre do aluno.
•A média final do aluno.
•Mostrar o conceito referente a média final, como informado na Tabela 1.
•A quantidade de alunos por conceito.
•A média da turma por bimestre na disciplina.
•A média final da turma na disciplina.

Média Final(MF) Conceito
8,5 ≤ MF ≤ 10   A - Ótimo
7 ≤ MF < 8,5    B - Bom 
5 ≤ MF < 7      C - Regular
0 ≤ MF < 5      D - Insuficiente
 */

/**
 *
 * @author andre
 */
import java.util.Scanner;

public class Exercicio1 {

    public static void main(String[] args) {
        double prova, lista, bimestre1, bimestre2, mediaFinal, mediaBimestral1 = 0, mediaBimestral2 = 0, mediaFinalGeral = 0;
        int otimo = 0, bom = 0, regular = 0, insuficiente = 0;
        Scanner leia = new Scanner(System.in);

        for (int i = 1; i <= 8; i++) {
            System.out.print("Escreva a nota da prova do primeiro bimestre do " + i + "° aluno: ");
            prova = leia.nextDouble();
            System.out.print("Escreva a nota da lista do primeiro bimestre do " + i + "° aluno: ");
            lista = leia.nextDouble();

            bimestre1 = ((prova * 8) + (lista * 2)) / (8 + 2);
            mediaBimestral1 = mediaBimestral1 + bimestre1;

            System.out.println("A média do primeiro bimestre do " + i + "° aluno foi de: " + bimestre1);

            System.out.print("Escreva a nota da prova do segundo bimestre do " + i + "° aluno: ");
            prova = leia.nextDouble();
            System.out.print("Escreva a nota da lista do segundo bimestre do " + i + "° aluno: ");
            lista = leia.nextDouble();

            bimestre2 = ((prova * 8) + (lista * 2)) / (8 + 2);
            mediaBimestral2 = mediaBimestral2 + bimestre2;

            System.out.println("A média do segundo bimestre do " + i + "° aluno foi de: " + bimestre2);

            mediaFinal = (bimestre1 + bimestre2) / 2;
            mediaFinalGeral = mediaFinalGeral + mediaFinal;

            System.out.println("A média final do " + i + "° aluno foi de: " + mediaFinal);

            if (mediaFinal >= 8.5 && mediaFinal <= 10) {
                otimo++;
                System.out.println("O " + i + "° aluno ficou no conceito A - Ótimo!");
            } else if (mediaFinal >= 7 && mediaFinal < 8.5) {
                bom++;
                System.out.println("O " + i + "° aluno ficou no conceito B - Bom!");
            } else if (mediaFinal >= 5 && mediaFinal < 7) {
                regular++;
                System.out.println("O " + i + "° aluno ficou no conceito C - Regular.");
            } else {
                insuficiente++;
                System.out.println("O " + i + "° aluno ficou no conceito D - Insuficiente...");
            }
        }
        System.out.println("Quantidade de alunos por conceito: ");
        System.out.println("A - Ótimo: " + otimo);
        System.out.println("B - Bom: " + bom);
        System.out.println("C - Regular: " + regular);
        System.out.println("D - Insuficiente: " + insuficiente);
        
        mediaBimestral1 = (mediaBimestral1 / 8);
        System.out.println("A média do primeiro bimestre da turma foi de: " + mediaBimestral1);
        
        mediaBimestral2 = (mediaBimestral2 / 8);
        System.out.println("A média do segundo bimestre da turma foi de: " + mediaBimestral2);
        
        mediaFinalGeral = (mediaFinalGeral / 8);
        System.out.println("A média final da turma foi de: " + mediaFinalGeral);
    }
}
