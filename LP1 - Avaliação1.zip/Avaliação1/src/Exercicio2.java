/*
2)Faça um programa que leia o valor de nove carros comprados por uma empresa. O programa deve ter as saídas a seguir: 
•O valor total da compra dos carros.
•O valor total da compra descontando o imposto de 42%.
•O lucro da concessionária que vendeu os carros, considere que é 21% sobre o valor da compra descontando o imposto. 
•O carro com maior preço.
•Considere que a manutenção dos carros nos próximos 5 anos custa: 10% do valor total de cada carro com preço inferior a R$45000,00 e 18% para os demais. Informe o total gasto nas manutenções de todos os carros.
•A média dos gastos da empresa por carro: considere o valor total gasto na compra dos carros e na manutenção dos próximos 5 anos.
 */

/**
 *
 * @author andre
 */
import java.util.Scanner;

public class Exercicio2 {

    public static void main(String[] args) {
      double precoCarro, maiorPreco = 0, totalPreco = 0, manutencao = 0;
      int maiorPrecoCarro = 0;
      Scanner leia = new Scanner(System.in);
      
      for(int i = 1; i <= 9; i++) {
          System.out.print("Digite o valor do " + i + "° carro: ");
          precoCarro = leia.nextDouble();
          
          totalPreco = totalPreco + precoCarro;
          
          if(precoCarro > maiorPreco) {
              maiorPreco = precoCarro;
              maiorPrecoCarro = i;
          }
          if(precoCarro < 45000) {
              manutencao = manutencao + (precoCarro * 0.10);
          } else {
              manutencao = manutencao + (precoCarro * 0.18);
          }
      }
      System.out.println("O valor total da compra dos carros foi de: " + totalPreco);
      System.out.println("O valor total da compra dos carros, descontando o imposto de 42%, foi de: " + totalPreco * 0.52);
      System.out.println("O lucro da concessionária foi de: " + (totalPreco * 0.52) * 0.21);
      System.out.println("O carro que teve o maior preço foi o " + maiorPrecoCarro + "° carro, com o preço de: " + maiorPreco);
      System.out.println("O valor total gasto na manutenção de todos os carros nos proximos 5 anos é de: " + manutencao);
      System.out.println("A média de gastos da empresa por carro é de: " + (totalPreco + manutencao) / 9);
    }
}
