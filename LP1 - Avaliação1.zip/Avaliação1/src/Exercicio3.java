/*
3) Escreva um programa que leia as opções de 5 a 9, onde: 
•opção = 5 - ler um número inteiro e informar se o número é múltiplo de 9;  
•opção = 6 - ler uma mensagem e informar a quantidade de caracteres;  
•opção = 7 - ler uma mensagem e informar o décimo caractere, caso a mensagem seja menor que dez caracteres, informe o último caractere da mensagem; 
•opção = 8 -  ler uma mensagem e apresentar ela invertida (ex: mensagem1  => 1megasnem);
•opção = 9 - ler o ano de nascimento de uma pessoa e o ano atual, depois informar a idade em minutos da pessoa (considere que o ano tem 365 dias). 
Faça as implementações e saídas necessárias de acordo com o valor da opção informada
OBS: Se a Opção informada for diferente das solicitadas, informe para o usuário a mensagem: “Entrada Incorreta!”.
 */

/**
 *
 * @author andre
 */
import java.util.Scanner;

public class Exercicio3 {

    public static void main(String[] args) {
        String pal1;
        int opcao, num, ano;
        Scanner leia = new Scanner(System.in);
        System.out.print("Digite uma mensagem: ");
        pal1 = leia.nextLine();

        System.out.println("Agora escolha uma das opções: ");
        System.out.println("5 - Informar se um número é multiplo de 9");
        System.out.println("6 - Informar o número de caracteres de uma mensagem");
        System.out.println("7 - Informar o décimo caractere de uma mensagem (ou o ultimo se for menor que 10 caracteres)");
        System.out.println("8 - Inverter uma mensagem");
        System.out.println("9 - Ler o seu ano de nascimento e ano atual e informar a sua idade em minutos.");
        System.out.print("Opção: ");
        opcao = leia.nextInt();

        switch (opcao) {
            case 5:
                System.out.print("Digite um número: ");
                num = leia.nextInt();

                if (num % 9 == 0) {
                    System.out.println("O número é SIM multiplo de 9.");
                } else {
                    System.out.println("O numero NÃO é multiplo de 9.");
                }
                break;
            case 6:
                System.out.println("O número de caracteres dessa mensagem foi de: " + pal1.length());
                break;
            case 7:
                if (pal1.length() >= 10) {
                    System.out.println("O décimo caractere da mensagem é: " + pal1.charAt(9));
                } else {
                    System.out.println("O último caractere da mensagem é: " + pal1.charAt(pal1.length() - 1));
                }
                break;
            case 8:
                System.out.print("A palavra invertida é: ");
                for (int i = 1; i <= pal1.length(); i++) {
                    System.out.print(pal1.charAt(pal1.length() - i));
                }
                System.out.println("");
                break;
            case 9:
                System.out.print("Informe o seu ano de nascimento: ");
                num = leia.nextInt();
                System.out.print("Agora informe o ano atual: ");
                ano = leia.nextInt();
                
                System.out.println("A sua idade em minutos é: " + (((ano - num) * 365) * 24) * 60);
                break;
            default:
                System.out.println("Entrada Incorreta!");
                break;

        }
    }
}
