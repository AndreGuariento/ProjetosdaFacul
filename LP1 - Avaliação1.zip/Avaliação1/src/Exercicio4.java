/*
4) Calcule a soma dos 50 primeiros termos da série T, determinado por: T= 3/500 + 5/490 + 7/480 + 9/470 + 11/460 + 13/450...
 */

/**
 *
 * @author andre
 */
import java.util.Scanner;

public class Exercicio4 {

    public static void main(String[] args) {
        double denom = 510;
        double soma = 0;
        Scanner leia = new Scanner(System.in);
        
        for(double i = 3; i < 103 ; i = i + 2) {
            denom = denom - 10;
            soma = soma + i/denom;
        }
        System.out.println("O valor dos primeiros 50 termos é: " + soma);
    }
}
