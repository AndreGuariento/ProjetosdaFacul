/*
1)  Faça   um   programa   com   menu   utilizando   os  métodos  solicitados   no   desenvolvimento   das funcionalidades desejadas.  [4,0 pontos]
Métodos:
Um método que receba uma matriz de números reais e inicialize com zero todas as posições. v
Um método que receba uma matriz de números reais e faça a impressão da matriz. v
Um método que receba uma matriz de números reais e o número da coluna que deve ser impressa. v
Um método que receba uma matriz de números reais e o número da coluna que deve ser feita a leitura. v
Um método que receba uma matriz de números reais e retorne a soma dos valores da matriz. v
Funcionalidades:  Considere que a empresa que utiliza o sistema possui  cinco  funcionários, os pagamentos dos funcionários  são mensais e são armazenados os  dados do semestre corrente. Utilize uma matriz 5x6 e os métodos solicitados acima no desenvolvimento do sistema. 
1- Zerar folha de pagamento (Obrigatório no primeiro uso do sistema).
2 - Cadastrar folha de pagamento de um mês específico.
3 – Imprimir folha de pagamento de um mês específico.
4 – Imprimir a folha de pagamento completa.
5 – Custo da folha de pagamento. 
0 – Sair.
*** É necessário que o programa principal faça chamadas de todos os métodos previamente implementados.***
 */

/**
 *
 * @author andre
 */
import java.util.Scanner;

public class Exercicio1 {
    
    static Scanner leia = new Scanner(System.in);
      
    public static void imprimeMatriz(double mat[][]){
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print("\t" + mat[i][j] + " ");
            }
            System.out.println("");
        }
    }
    
    public static void inicializaMatriz(double mat[][]){
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                mat[i][j] = 0;
            }
            System.out.println("");
        }
    }
    
    public static void lerColunaMatriz(double mat[][], int j){
        for (int i = 0; i < mat.length; i++) {
            System.out.print("Digite o salario do " + (i+1) +"º funcionário: ");
           mat[i][j] = leia.nextDouble();
        }
    }
    
    public static void imprimeColunaMatriz(double mat[][], int j){
        for (int i = 0; i < mat.length; i++) {
           System.out.print("\t" + mat[i][j] + " ");
        }
        System.out.println(" ");
    }
    
    public static double somaMatriz(double mat[][]) {
        double soma = 0;
        for (int i = 0; i < mat.length; i++) {
           for (int j = 0; j < mat[i].length; j++) {
            soma = soma + mat[i][j];
        } 
        }
        return soma;
    }    

    public static void main(String[] args) {
      double m[][] = new double[5][6];
      int escolha, mes;
        
        System.out.println("Bem vindo ao sistema de organização de pagamento do nossa empresa!");
        System.out.println("1- Zerar folha de pagamento (Obrigatório no primeiro uso do sistema).");
        System.out.println("2 - Cadastrar folha de pagamento de um mês específico.");
        System.out.println("3 – Imprimir folha de pagamento de um mês específico.");
        System.out.println("4 – Imprimir a folha de pagamento completa.");
        System.out.println("5 – Custo da folha de pagamento.");
        System.out.println("0 – Sair.");
        System.out.print("Digite o número do que deseja fazer: ");
        escolha = leia.nextInt();
        
        while(escolha > 0){
           switch(escolha){
            case 1:
                inicializaMatriz(m);
                break;
            case 2:
                System.out.println("Digite o mês: ");
                mes = leia.nextInt();
                lerColunaMatriz(m, mes);
                break;
            case 3:
                System.out.println("Digite o mês: ");
                mes = leia.nextInt();
                imprimeColunaMatriz(m, mes);
                break;
            case 4:
                imprimeMatriz(m);
                break;
            case 5:
                somaMatriz(m);
                double soma = somaMatriz(m);
                System.out.println("O custo da folha de pagamento é de: " + soma);
                break;
            case 0:
                break;
            default:
                System.out.println("Opção inválida!");
        } 
            System.out.println("**********************************************************");
            System.out.println("1- Zerar folha de pagamento.");
            System.out.println("2 - Cadastrar folha de pagamento de um mês específico.");
            System.out.println("3 – Imprimir folha de pagamento de um mês específico.");
            System.out.println("4 – Imprimir a folha de pagamento completa.");
            System.out.println("5 – Custo da folha de pagamento.");
            System.out.println("0 – Sair.");
            System.out.print("Digite o que mais deseja fazer: ");
            escolha = leia.nextInt();
        }
        
        
        
        
        
        
        
        }
    }
