/*
2)  Faça um programa que leia três vetores de 6 posições de inteiros (A, B e C) e que tenha como saída: 
•O vetor D resultante da multiplicação dos elementos de índices opostos, ou seja, o primeiro elemento do vetor A deve ser multiplicado com o último elemento do vetor B, e o resultadocolocado na primeira posição do vetor D, e assim por diante.
•O vetor E resultante da intercalação dos valores presentes nos vetores A, B e C .      [3,0pontos]
 */

/**
 *
 * @author andre
 */
/*
6. Faça um programa que leia dois vetores de tamanho 6 e que tenha como saída um terceiro vetorde tamanho 12 formado da intercalação dos valores dos dois vetores iniciais.
 */

/**
 *
 * @author andre
 */
import java.util.Scanner;

public class Exercicio2 {
    public static void imprimeVetor(int vet[]) {
        for (int i = 0; i < vet.length; i++) {
            System.out.print("\t" + vet[i] + ", ");
        }
        System.out.println("");
    }

    public static void main(String[] args) {
      Scanner leia = new Scanner(System.in);
      int A[] = new int[6];
      int B[] = new int[6];
      int C[] = new int[6];
      int D[] = new int[6];
      int E[] = new int[6];
      int j = 5;
      
        for (int i = 0; i < 6; i++) {
            A[i] = 3 + i;
            B[i] = 7 + i;
            C[i] = 9 + i;
        }
        
        for (int i = 0; i < 6; i++) {
            D[i] = A[i] * B[j];
            j--;
        }
        
        for (int i = 0; i < 2; i++) {
               E[i * 3] = A[i];
               E[i * 3 + 1] = B[i];
               E[i * 3 + 2] = C[i];
        }
        System.out.print("A: ");
        imprimeVetor(A);
        System.out.println(" ");
        System.out.print("B: ");
        imprimeVetor(B);
        System.out.println(" ");
        System.out.print("C: ");
        imprimeVetor(C);
        System.out.println(" ");
        System.out.print("D: ");
        imprimeVetor(D);
        System.out.println(" ");
        System.out.print("E: ");
        imprimeVetor(E);
        System.out.println(" ");
            
        }
    }
