/*
3)  Faça um programa que leia uma matriz M (5x4), a matriz será utilizada para armazenar as notasde 4 bimestres (coluna) de 5 alunos (linha). Considere que no momento do preenchimento da matriz,o usuário comenta os seguintes erros:•Inverteu o local das notas do terceiro e segundo bimestre dos alunos.
•As notas do primeiro aluno foram trocadas com a do quarto aluno.
•Cada aluno deveria ter ganho um ponto extra no segundo bimestre.O programa deve ter como saída a matriz com as correções necessárias e um vetor com as médiasfinais de cada aluno. Após o cálculo da média final, informe a quantidade de alunos:  aprovados(media>= 7), Reprovados (media <= 5) e de Recuperação (media entre 5.1 a 6.9).  [3,0 pontos]
 */

/**
 *
 * @author andre
 */
import java.util.Scanner;

public class Exercicio3 {
    
    static Scanner leia = new Scanner(System.in);
      
    public static void imprimeMatriz(double mat[][]){
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print("\t" + mat[i][j] + " ");
            }
            System.out.println("");
        }
    }
    
    public static void lerMatriz(double mat[][]){
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print("Digite a nota do " + (j+1) + "º bimestre do " + (i+1) + "° aluno: ");
                mat[i][j] = leia.nextDouble();
            }
            System.out.println("");
        }
    }
    
    public static void trocaMatrizLinha(double mat[][], int i, int i2){
        for (int k = 0; k < mat[i].length; k++) {
          double aux = mat[i][k];
          mat[i][k] = mat[i2][k];
          mat[i2][k] = aux;
        }
    }
    public static void trocaMatrizColuna(double mat[][], int i, int i2){
        for (int k = 0; k < mat.length; k++) {
          double aux = mat[k][i];
          mat[k][i] = mat[k][i2];
          mat[k][i2] = aux;
        }
    }
    
    public static void pontoExtraColunaMatriz(double mat[][], int j) {
        for (int i = 0; i < mat.length; i++) {
            mat[i][j]++;
        } 
        
    }
    public static double mediaLinhaMatriz(double mat[][], int i) {
        double soma = 0;
        for (int j = 0; j < mat[i].length; j++) {
            soma = soma + mat[i][j];
        }
        return soma / mat[i].length;
    }
    public static void imprimeVetor(double vet[]) {
        for (int i = 0; i < vet.length; i++) {
            System.out.print("\t" + vet[i] + ", ");
        }
        System.out.println("");
    }


    public static void main(String[] args) {
      double m[][] = new double[5][4];
      double v[] = new double[5];
      int aprovados = 0, reprovados = 0, recuperacao = 0;
      double soma;
      
      lerMatriz(m);
      trocaMatrizColuna(m, 2, 3);
      trocaMatrizLinha(m, 0, 3);
      pontoExtraColunaMatriz(m, 1);
      
        for (int i = 0; i < m.length; i++) {
            soma = mediaLinhaMatriz(m, i);
            v[i] = soma;
            if(soma >= 7) {
                aprovados++;
            } else if(soma >= 5.1 && soma <= 6.9) {
                recuperacao++;
            } else {
                reprovados++;
            }  
        }
        imprimeMatriz(m);
        System.out.println("Médias: ");
        imprimeVetor(v);
        System.out.println("Houveram:");
        System.out.println(aprovados + " alunos aprovados.");
        System.out.println(recuperacao + " alunos em recuperacao.");
        System.out.println(reprovados + " alunos reprovados.");
    }
}
