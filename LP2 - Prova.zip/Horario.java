// Aluno: André Augusto Borges Guariento
// Curso: Sistemas para Internet
// Turma: 178
// Matéria: Linguagem de Programação 2

package horario;

/**
 *
 * @author andre
 */
public class Horario {

    private int hora;
    private int minuto;
    private int segundo;
    
    Horario(int hora, int minuto, int segundo) {
        this.hora = hora;
        this.minuto = minuto;
        this.segundo = segundo;
        arrumaHorario();
    }
    
    public void aumentaUmSegundo() {
        if(segundo + 1 == 60) {
           segundo++;
           arrumaHorario();
        } else {
            segundo++;
        }
    }
    
    public void print() {
        String zeroHora = String.valueOf(hora);
        String zeroMinuto = String.valueOf(minuto);
        String zeroSegundo = String.valueOf(segundo);
        
        if(hora < 10) {
            zeroHora = "0" + String.valueOf(hora);
        }
        if(minuto < 10) {
            zeroMinuto = "0" + String.valueOf(minuto);
        }
        if(segundo < 10) {
            zeroSegundo = "0" + String.valueOf(segundo);
        }
        System.out.println(zeroHora + ":" + zeroMinuto + ":" + zeroSegundo);
    }
    public void printAMPM() {
        int horaAMPM = hora;
        if(hora > 12) {
          horaAMPM =  hora - 12; 
        } else if(hora == 0) {
          horaAMPM = hora + 12;  
        }
        String zeroHora = String.valueOf(horaAMPM);
        String zeroMinuto = String.valueOf(minuto);
        String zeroSegundo = String.valueOf(segundo);
        
        if(horaAMPM < 10) {
            zeroHora = "0" + String.valueOf(horaAMPM);
        }
        if(minuto < 10) {
            zeroMinuto = "0" + String.valueOf(minuto);
        }
        if(segundo < 10) {
            zeroSegundo = "0" + String.valueOf(segundo);
        }
        if(hora > 12) {
            System.out.println(zeroHora + ":" + zeroMinuto + ":" + zeroSegundo + " PM"); 
        } else {
            System.out.println(zeroHora + ":" + zeroMinuto + ":" + zeroSegundo + " AM");
        }
    }
    private void arrumaHorario() {
      if(segundo < 0) {
            segundo = segundo * -1;
        }
      while(segundo >= 60) {
            segundo = segundo - 60;
            minuto++;
      }
      if(minuto < 0) {
          minuto = minuto * -1;
          
      }
      while(minuto >= 60) {
          minuto = minuto - 60;
          hora++;
      }
      if(hora < 0) {
          hora = hora * -1;
      }
      while(hora >= 24) {
          hora = hora - 24;
      }
    }
    
    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
         this.hora = hora;
         arrumaHorario();
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
        arrumaHorario();
    }

    public int getSegundo() {
        return segundo;
    }

    public void setSegundo(int segundo) {
        this.segundo = segundo;
        arrumaHorario();
    }
    
}
