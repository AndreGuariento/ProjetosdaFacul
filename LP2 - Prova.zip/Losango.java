// Aluno: André Augusto Borges Guariento
// Curso: Sistemas para Internet
// Turma: 178
// Matéria: Linguagem de Programação 2
package poligono;

/**
 *
 * @author andre
 */
public class Losango extends Poligono {
    
    Losango() {
        
    }
    Losango(double diagonal1, double diagonal2) {
        super(diagonal1, diagonal2);
    }
    @Override
    public double area(){
        return super.area() / 2;
    }
}
