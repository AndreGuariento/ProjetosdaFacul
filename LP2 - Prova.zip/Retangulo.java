// Aluno: André Augusto Borges Guariento
// Curso: Sistemas para Internet
// Turma: 178
// Matéria: Linguagem de Programação 2
package poligono;

/**
 *
 * @author andre
 */
public class Retangulo extends Poligono {
    
    Retangulo() {
        
    }
    Retangulo(double altura, double base) {
        super(altura, base);
    }
}
