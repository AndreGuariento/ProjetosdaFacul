// Aluno: André Augusto Borges Guariento
// Curso: Sistemas para Internet
// Turma: 178
// Matéria: Linguagem de Programação 2

package poligono;

/**
 *
 * @author andre
 */
public class Triangulo extends Poligono {
    
    Triangulo() {
        
    }
    Triangulo(double altura, double base) {
        super(altura, base);
    }
    @Override
    public double area() {
       return super.area() / 2;
    }
    
}
