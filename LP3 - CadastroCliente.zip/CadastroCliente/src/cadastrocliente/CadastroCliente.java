
package cadastrocliente;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author andre
 */
public class CadastroCliente {

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        ArrayList<Object> Cliente = new ArrayList<>();
        int escolha;
        int id;
        String nome;
        String email;
        String telefone;
        String endereco;
        int indnum;

        do {
            System.out.println("------------- Menu de cadastro de Cliente --------------");
            System.out.println("1 - Inserir");
            System.out.println("2 - Deletar");
            System.out.println("3 - Atualizar");
            System.out.println("4 - Listar");
            System.out.println("5 - Sair");
            System.out.print("Digite o que deseja fazer: ");
            escolha = leia.nextInt();

            switch (escolha) {
                case 1:
                    System.out.print("Digite o ID: ");
                    id = leia.nextInt();
                    System.out.print("Digite o nome: ");
                    nome = leia.next();
                    System.out.print("Digite o email: ");
                    email = leia.next();
                    System.out.print("Digite o telefone: ");
                    telefone = leia.next();
                    System.out.print("Digite o endereço: ");
                    endereco = leia.next();

                    Cliente.add(id + " | " + nome + " | " + email + " | " + telefone + " | " + endereco);
                    System.out.println("Cliente inserido com sucesso!");
                    break;
                case 2:
                    if(Cliente.isEmpty()) {
                        System.out.println("Não há clientes cadastrados");
                        break;
                    }
                    System.out.print("Digite o número do cliente na qual deseja deletar:");
                    indnum = leia.nextInt();
                    Cliente.remove(indnum);
                    System.out.println("Cliente removido com sucesso.");
                    break;
                case 3:
                    if(Cliente.isEmpty()) {
                        System.out.println("Não há clientes cadastrados");
                        break;
                    }
                    do {
                        System.out.print("Digite o número do cliente na qual deseja atualizar:");
                        indnum = leia.nextInt();
                        
                        if(indnum > Cliente.size() - 1) {
                            System.out.println("Número inválido!");
                        }
                        
                    } while(indnum > Cliente.size() - 1);
                    System.out.print("Digite o ID: ");
                    id = leia.nextInt();
                    System.out.print("Digite o nome: ");
                    nome = leia.next();
                    System.out.print("Digite o email: ");
                    email = leia.next();
                    System.out.print("Digite o telefone: ");
                    telefone = leia.next();
                    System.out.print("Digite o endereço: ");
                    endereco = leia.next();
                    Cliente.set(indnum, id + " | " + nome + " | " + email + " | " + telefone + " | " + endereco);
                    System.out.println("Cliente atualizado com sucesso.");
                    break;
                case 4:
                    for (int i = 0; i < Cliente.size(); i++) {
                        System.out.println(Cliente.get(i));
                    }
                    break;
                case 5:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Valor inválido!");
                    break;
            }

        } while (escolha != 5);
    }

}
