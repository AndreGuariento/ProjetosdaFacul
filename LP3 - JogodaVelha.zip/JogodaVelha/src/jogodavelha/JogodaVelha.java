/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jogodavelha;

import java.util.Scanner;

/**
 *
 * @author andre
 */
public class JogodaVelha {

    static String jogo[][] = new String[3][3];

    public static void escrevaMatriz() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (j == 2) {
                    if (jogo[i][j] == null) {
                        System.out.print(" ");
                    } else {
                        System.out.print(jogo[i][j]);
                    }
                } else {
                    if (jogo[i][j] == null) {
                        System.out.print(" " + " | ");
                    } else {
                        System.out.print(jogo[i][j] + " | ");
                    }
                }

            }
            System.out.println(" ");
            if (i == 2) {
                System.out.println(" ");
            } else {
                System.out.println("---------");
            }
        }

    }

    public static boolean checaFimJogo() {
        int fim = 0;
        for (int i = 0; i < 3; i++) {
            if (jogo[i][0] == "X" && jogo[i][1] == "X" && jogo[i][2] == "X") {
                fim++;
            }
            if (jogo[i][0] == "O" && jogo[i][1] == "O" && jogo[i][2] == "O") {
                fim++;
            }
            if (jogo[0][i] == "X" && jogo[1][i] == "X" && jogo[2][i] == "X") {
                fim++;
            }
            if (jogo[0][i] == "O" && jogo[1][i] == "O" && jogo[2][i] == "O") {
                fim++;
            }
        }
        if (jogo[0][0] == "X" && jogo[1][1] == "X" && jogo[2][2] == "X") {
            fim++;
        }
        if (jogo[0][0] == "O" && jogo[1][1] == "O" && jogo[2][2] == "O") {
            fim++;
        }
        if (jogo[0][2] == "X" && jogo[1][1] == "X" && jogo[2][0] == "X") {
            fim++;
        }
        if (jogo[0][2] == "O" && jogo[1][1] == "O" && jogo[2][0] == "O") {
            fim++;
        }
        return fim > 0;
    }

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        int posx;
        int posy;
        int turno = 0;
        boolean acabou = false;

        do {
            do {
                escrevaMatriz();
                if (turno % 2 == 0) {
                    System.out.println("Vez do jogador 1");
                } else {
                    System.out.println("Vez do jogador 2");
                }
                do {
                    System.out.println("Digite a linha: ");
                    posx = leia.nextInt();
                    posx--;
                    if (posx < 0 || posx > 2) {
                        System.out.println("Valor invalido!");
                    }

                } while (posx < 0 || posx > 2);

                do {
                    System.out.println("Digite a coluna:");
                    posy = leia.nextInt();
                    posy--;

                    if (posy < 0 || posy > 2) {
                        System.out.println("Valor invalido!");
                    }

                } while (posy < 0 || posy > 2);

                if (jogo[posx][posy] != null) {
                    System.out.println("Quadrado já ocupado!");
                }
            } while (jogo[posx][posy] != null);

            if (turno % 2 == 0) {
                jogo[posx][posy] = "X";
                turno++;
            } else {
                jogo[posx][posy] = "O";
                turno++;
            }

            acabou = checaFimJogo();

        } while (acabou == false);
        
        escrevaMatriz();
        
        System.out.println("Fim de jogo!");
        
        if(turno % 2 == 0) {
            System.out.println("Jogador 2 é o vencedor!");
        } else {
            System.out.println("Jogador 1 é o vencedor!");
        }

    }

}
